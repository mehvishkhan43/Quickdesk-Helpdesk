import { createUser, getUserByEmail, setCurrentUser, getCurrentUser } from './storage';
import { User } from '@/types';

export const register = (
  email: string,
  password: string,
  name: string,
  role: 'user' | 'agent' | 'admin' = 'user'
): { user: User; error?: never } | { user?: never; error: string } => {
  try {
    // Check if user already exists
    const existingUser = getUserByEmail(email);
    if (existingUser) {
      return { error: 'User with this email already exists' };
    }

    // Store password in localStorage (in a real app, this would be hashed)
    localStorage.setItem(`quickdesk_password_${email}`, password);

    // Create new user
    const user = createUser({
      email,
      name,
      role,
    });

    // Set as current user
    setCurrentUser(user.id);

    return { user };
  } catch (error) {
    return { error: 'Failed to register user' };
  }
};

export const login = (
  email: string,
  password: string
): { user: User; error?: never } | { user?: never; error: string } => {
  try {
    // Find user by email
    const user = getUserByEmail(email);
    if (!user) {
      return { error: 'User not found' };
    }

    // Check password (in a real app, this would compare hashes)
    const storedPassword = localStorage.getItem(`quickdesk_password_${email}`);
    if (password !== storedPassword) {
      return { error: 'Invalid password' };
    }

    // Set as current user
    setCurrentUser(user.id);

    return { user };
  } catch (error) {
    return { error: 'Failed to log in' };
  }
};

export const logout = (): void => {
  setCurrentUser(null);
};

export const isAuthenticated = (): boolean => {
  return getCurrentUser() !== null;
};

export const hasRole = (role: 'user' | 'agent' | 'admin'): boolean => {
  const user = getCurrentUser();
  if (!user) return false;
  
  // Admin has all permissions
  if (user.role === 'admin') return true;
  
  // Agent has agent and user permissions
  if (user.role === 'agent' && (role === 'agent' || role === 'user')) return true;
  
  // User only has user permissions
  return user.role === role;
};