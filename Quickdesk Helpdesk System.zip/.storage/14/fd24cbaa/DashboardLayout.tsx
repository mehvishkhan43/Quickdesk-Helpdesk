import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'react-router-dom';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  AlertCircle,
  BarChart3,
  Inbox,
  LifeBuoy,
  LogOut,
  PlusCircle,
  Settings,
  User,
  Users,
  Tag
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  
  const isAdmin = user?.role === 'admin';
  const isAgent = user?.role === 'agent' || user?.role === 'admin';
  
  const navigationItems = [
    {
      title: 'Dashboard',
      icon: BarChart3,
      href: '/dashboard',
      active: location.pathname === '/dashboard',
      show: true,
    },
    {
      title: 'All Tickets',
      icon: Inbox,
      href: '/dashboard/tickets',
      active: location.pathname === '/dashboard/tickets',
      show: true,
    },
    {
      title: 'Create Ticket',
      icon: PlusCircle,
      href: '/dashboard/create-ticket',
      active: location.pathname === '/dashboard/create-ticket',
      show: true,
    },
    {
      title: 'User Management',
      icon: Users,
      href: '/dashboard/users',
      active: location.pathname === '/dashboard/users',
      show: isAdmin,
    },
    {
      title: 'Category Management',
      icon: Tag,
      href: '/dashboard/categories',
      active: location.pathname === '/dashboard/categories',
      show: isAdmin,
    },
  ];
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };
  
  return (
    <div className="flex min-h-screen bg-gray-100 dark:bg-gray-900">
      {/* Desktop Sidebar */}
      <div className="hidden md:flex flex-col w-64 bg-white dark:bg-gray-800 border-r dark:border-gray-700">
        <div className="p-4 border-b dark:border-gray-700">
          <Link to="/" className="flex items-center">
            <LifeBuoy className="h-6 w-6 mr-2 text-blue-600 dark:text-blue-400" />
            <span className="text-xl font-semibold">QuickDesk</span>
          </Link>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          <nav className="space-y-1">
            {navigationItems.filter(item => item.show).map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className={cn(
                  'flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors',
                  item.active
                    ? 'bg-blue-100 text-blue-900 dark:bg-blue-900 dark:text-blue-100'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                )}
              >
                <item.icon className={cn('h-5 w-5 mr-2', item.active ? 'text-blue-600 dark:text-blue-400' : '')} />
                {item.title}
              </Link>
            ))}
          </nav>
        </div>
        
        <div className="p-4 border-t dark:border-gray-700">
          <div className="flex items-center">
            <Avatar>
              <AvatarImage src="" />
              <AvatarFallback>{user?.name ? getInitials(user.name) : '??'}</AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.name}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{user?.email}</p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="ml-auto">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => navigate('/dashboard/profile')}>
                  <User className="h-4 w-4 mr-2" /> Profile
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-2" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-20 bg-white dark:bg-gray-800 border-b dark:border-gray-700 p-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <LifeBuoy className="h-6 w-6 mr-2 text-blue-600 dark:text-blue-400" />
            <span className="text-xl font-semibold">QuickDesk</span>
          </Link>
          <Sheet open={isMobileNavOpen} onOpenChange={setIsMobileNavOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="3" y1="6" x2="21" y2="6" />
                  <line x1="3" y1="12" x2="21" y2="12" />
                  <line x1="3" y1="18" x2="21" y2="18" />
                </svg>
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <div className="py-6">
                <Link to="/" className="flex items-center mb-8" onClick={() => setIsMobileNavOpen(false)}>
                  <LifeBuoy className="h-6 w-6 mr-2 text-blue-600 dark:text-blue-400" />
                  <span className="text-xl font-semibold">QuickDesk</span>
                </Link>
                <nav className="space-y-2">
                  {navigationItems.filter(item => item.show).map((item) => (
                    <Link
                      key={item.href}
                      to={item.href}
                      className={cn(
                        'flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors',
                        item.active
                          ? 'bg-blue-100 text-blue-900 dark:bg-blue-900 dark:text-blue-100'
                          : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                      )}
                      onClick={() => setIsMobileNavOpen(false)}
                    >
                      <item.icon className={cn('h-5 w-5 mr-2', item.active ? 'text-blue-600 dark:text-blue-400' : '')} />
                      {item.title}
                    </Link>
                  ))}
                  <div className="pt-4 mt-4 border-t dark:border-gray-700">
                    <Link
                      to="/dashboard/profile"
                      className="flex items-center px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => setIsMobileNavOpen(false)}
                    >
                      <User className="h-5 w-5 mr-2" />
                      Profile
                    </Link>
                    <button
                      className="w-full flex items-center px-3 py-2 rounded-md text-sm font-medium text-red-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        handleLogout();
                        setIsMobileNavOpen(false);
                      }}
                    >
                      <LogOut className="h-5 w-5 mr-2" />
                      Logout
                    </button>
                  </div>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col md:ml-0 mt-16 md:mt-0">
        <main className="flex-1 p-4 md:p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}