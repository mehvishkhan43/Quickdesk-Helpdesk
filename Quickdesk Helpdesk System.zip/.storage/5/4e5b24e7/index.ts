export type User = {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'agent' | 'admin';
  createdAt: string;
};

export type Category = {
  id: string;
  name: string;
  description: string;
  createdAt: string;
};

export type TicketStatus = 'open' | 'in-progress' | 'resolved' | 'closed';

export type Ticket = {
  id: string;
  subject: string;
  description: string;
  categoryId: string;
  createdBy: string;
  assignedTo: string | null;
  status: TicketStatus;
  createdAt: string;
  updatedAt: string;
  attachmentUrl?: string;
  votes: {
    upvotes: number;
    downvotes: number;
    userVotes: Record<string, 'up' | 'down' | null>;
  };
};

export type Comment = {
  id: string;
  ticketId: string;
  content: string;
  createdBy: string;
  createdAt: string;
};