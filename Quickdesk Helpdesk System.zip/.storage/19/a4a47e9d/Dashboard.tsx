import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getTickets, getCategories, getCurrentUser } from '@/lib/storage';
import { Ticket, Category } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, BarChart3, CheckCircle, AlertCircle, Clock, Activity } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export default function Dashboard() {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const navigate = useNavigate();
  const user = getCurrentUser();

  useEffect(() => {
    const fetchData = () => {
      const allTickets = getTickets();
      const allCategories = getCategories();
      setTickets(allTickets);
      setCategories(allCategories);
    };

    fetchData();
  }, []);

  // Filter user tickets if regular user
  const userTickets = user?.role === 'user' 
    ? tickets.filter(ticket => ticket.createdBy === user.id)
    : tickets;

  // Calculate ticket statistics
  const openTickets = userTickets.filter(t => t.status === 'open').length;
  const inProgressTickets = userTickets.filter(t => t.status === 'in-progress').length;
  const resolvedTickets = userTickets.filter(t => t.status === 'resolved').length;
  const closedTickets = userTickets.filter(t => t.status === 'closed').length;
  const totalTickets = userTickets.length;

  // Calculate category distribution
  const categoryDistribution = categories.map(category => {
    const ticketsInCategory = userTickets.filter(t => t.categoryId === category.id).length;
    return {
      ...category,
      count: ticketsInCategory,
      percentage: totalTickets > 0 ? (ticketsInCategory / totalTickets) * 100 : 0
    };
  });

  // Get recent tickets
  const recentTickets = [...userTickets]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <Button onClick={() => navigate('/dashboard/create-ticket')}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Create Ticket
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Open Tickets</p>
                <p className="text-2xl font-bold">{openTickets}</p>
              </div>
              <div className="p-2 bg-yellow-100 dark:bg-yellow-900 rounded-full">
                <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-300" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">In Progress</p>
                <p className="text-2xl font-bold">{inProgressTickets}</p>
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-full">
                <Clock className="h-5 w-5 text-blue-600 dark:text-blue-300" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Resolved</p>
                <p className="text-2xl font-bold">{resolvedTickets}</p>
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-full">
                <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-300" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Tickets</p>
                <p className="text-2xl font-bold">{totalTickets}</p>
              </div>
              <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full">
                <BarChart3 className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Recent Tickets</CardTitle>
            <CardDescription>Latest ticket updates</CardDescription>
          </CardHeader>
          <CardContent>
            {recentTickets.length > 0 ? (
              <div className="space-y-4">
                {recentTickets.map((ticket) => (
                  <div
                    key={ticket.id}
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer transition"
                    onClick={() => navigate(`/dashboard/tickets/${ticket.id}`)}
                  >
                    <div className="flex items-center space-x-3">
                      {ticket.status === 'open' && (
                        <AlertCircle className="h-5 w-5 text-yellow-500" />
                      )}
                      {ticket.status === 'in-progress' && (
                        <Clock className="h-5 w-5 text-blue-500" />
                      )}
                      {ticket.status === 'resolved' && (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      )}
                      {ticket.status === 'closed' && (
                        <Activity className="h-5 w-5 text-gray-500" />
                      )}
                      <div>
                        <p className="font-medium">{ticket.subject}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(ticket.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-sm">
                      <span
                        className={`px-2 py-1 rounded-full text-xs ${
                          ticket.status === 'open'
                            ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                            : ticket.status === 'in-progress'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                            : ticket.status === 'resolved'
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                        }`}
                      >
                        {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-muted-foreground">No tickets yet</p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => navigate('/dashboard/create-ticket')}
                >
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Create Your First Ticket
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Category Distribution */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Category Distribution</CardTitle>
            <CardDescription>Tickets by category</CardDescription>
          </CardHeader>
          <CardContent>
            {categoryDistribution.length > 0 ? (
              <div className="space-y-4">
                {categoryDistribution
                  .filter(cat => cat.count > 0)
                  .sort((a, b) => b.count - a.count)
                  .map((category) => (
                    <div key={category.id} className="space-y-2">
                      <div className="flex justify-between">
                        <span>{category.name}</span>
                        <span>{category.count} tickets</span>
                      </div>
                      <Progress value={category.percentage} className="h-2" />
                    </div>
                  ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-muted-foreground">No category data available</p>
              </div>
            )}

            {categoryDistribution.filter(cat => cat.count > 0).length === 0 && totalTickets > 0 && (
              <div className="text-center py-6">
                <p className="text-muted-foreground">No category data available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}