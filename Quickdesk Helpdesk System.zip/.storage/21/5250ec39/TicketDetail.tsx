import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getTicketById, getCommentsByTicketId, getUserById, getCategoryById, updateTicket, createComment, voteTicket, getCurrentUser } from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle,
  Clock,
  Archive,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function TicketDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const currentUser = getCurrentUser();
  
  const [ticket, setTicket] = useState<any>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  
  const isAgent = currentUser?.role === 'agent' || currentUser?.role === 'admin';
  const isOwner = ticket?.createdBy === currentUser?.id;
  const canChangeStatus = isAgent || (isOwner && ticket?.status === 'resolved');
  
  useEffect(() => {
    const loadTicket = () => {
      if (!id) return;
      
      const fetchedTicket = getTicketById(id);
      if (!fetchedTicket) {
        toast({
          title: "Ticket not found",
          description: "The requested ticket could not be found.",
          variant: "destructive",
        });
        navigate('/dashboard/tickets');
        return;
      }
      
      setTicket(fetchedTicket);
      setSelectedStatus(fetchedTicket.status);
      
      const fetchedComments = getCommentsByTicketId(id);
      setComments(fetchedComments);
      setLoading(false);
    };
    
    loadTicket();
  }, [id, navigate, toast]);
  
  const handleVote = (voteType: 'up' | 'down') => {
    if (!ticket || !currentUser) return;
    
    // If user already voted the same way, remove vote
    const currentVote = ticket.votes.userVotes[currentUser.id];
    const newVote = currentVote === voteType ? null : voteType;
    
    const updatedTicket = voteTicket(ticket.id, currentUser.id, newVote);
    if (updatedTicket) {
      setTicket(updatedTicket);
      
      toast({
        title: newVote ? "Vote recorded" : "Vote removed",
        description: newVote ? `You ${newVote}voted this ticket.` : "Your vote has been removed.",
      });
    }
  };
  
  const handleStatusChange = (status: string) => {
    if (!ticket || !canChangeStatus) return;
    
    setSelectedStatus(status);
    const updatedTicket = updateTicket(ticket.id, { status });
    
    if (updatedTicket) {
      setTicket(updatedTicket);
      
      toast({
        title: "Status updated",
        description: `Ticket status changed to ${status}.`,
      });
    }
  };
  
  const handleSubmitComment = () => {
    if (!newComment.trim() || !currentUser || submittingComment) return;
    
    setSubmittingComment(true);
    
    const comment = createComment({
      ticketId: ticket.id,
      content: newComment.trim(),
      createdBy: currentUser.id,
    });
    
    // Update UI
    setComments([...comments, comment]);
    setNewComment('');
    
    // Notify about success
    toast({
      title: "Comment added",
      description: "Your comment has been posted successfully.",
    });
    
    setSubmittingComment(false);
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'open':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'in-progress':
        return <Clock className="h-5 w-5 text-blue-500" />;
      case 'resolved':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'closed':
        return <Archive className="h-5 w-5 text-gray-500" />;
      default:
        return null;
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-300 dark:bg-yellow-900 dark:text-yellow-200 dark:border-yellow-700">
            Open
          </Badge>
        );
      case 'in-progress':
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300 dark:bg-blue-900 dark:text-blue-200 dark:border-blue-700">
            In Progress
          </Badge>
        );
      case 'resolved':
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300 dark:bg-green-900 dark:text-green-200 dark:border-green-700">
            Resolved
          </Badge>
        );
      case 'closed':
        return (
          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-300 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700">
            Closed
          </Badge>
        );
      default:
        return null;
    }
  };
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };
  
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Skeleton className="h-6 w-6" />
          <Skeleton className="h-8 w-48" />
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-full mb-2" />
            <Skeleton className="h-4 w-24" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-24 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (!ticket) {
    return (
      <div className="flex flex-col items-center justify-center space-y-4 p-8">
        <AlertCircle className="h-16 w-16 text-red-500" />
        <h2 className="text-2xl font-bold">Ticket Not Found</h2>
        <p>The ticket you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate('/dashboard/tickets')}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Tickets
        </Button>
      </div>
    );
  }
  
  const creator = getUserById(ticket.createdBy);
  const category = getCategoryById(ticket.categoryId);
  const assignedTo = ticket.assignedTo ? getUserById(ticket.assignedTo) : null;
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => navigate('/dashboard/tickets')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold">Ticket Details</h1>
        </div>
        
        <div className="flex items-center gap-3">
          {canChangeStatus && (
            <Select value={selectedStatus} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Change status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="open">Open</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          )}
          
          {!canChangeStatus && getStatusBadge(ticket.status)}
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between">
            <div>
              <CardTitle>{ticket.subject}</CardTitle>
              <CardDescription>
                {getStatusIcon(ticket.status)}
                <span className="ml-1 inline-block">
                  Created {new Date(ticket.createdAt).toLocaleDateString()} by {creator?.name || 'Unknown User'}
                </span>
              </CardDescription>
            </div>
            
            <div className="flex flex-col items-end">
              {category && <Badge variant="outline">{category.name}</Badge>}
              
              <div className="flex mt-2 gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex items-center gap-1"
                  onClick={() => handleVote('up')}
                >
                  <ThumbsUp 
                    className={`h-4 w-4 ${
                      ticket.votes.userVotes[currentUser?.id || ''] === 'up' 
                        ? 'text-green-600 fill-green-600' 
                        : ''
                    }`} 
                  />
                  <span>{ticket.votes.upvotes}</span>
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex items-center gap-1"
                  onClick={() => handleVote('down')}
                >
                  <ThumbsDown 
                    className={`h-4 w-4 ${
                      ticket.votes.userVotes[currentUser?.id || ''] === 'down' 
                        ? 'text-red-600 fill-red-600' 
                        : ''
                    }`} 
                  />
                  <span>{ticket.votes.downvotes}</span>
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md whitespace-pre-wrap">
            {ticket.description}
          </div>
          
          {/* Assigned agent info */}
          {assignedTo && (
            <div className="border border-gray-200 dark:border-gray-700 p-4 rounded-md">
              <h3 className="font-medium mb-2">Assigned Support Agent</h3>
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src="" />
                  <AvatarFallback>{getInitials(assignedTo.name)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{assignedTo.name}</p>
                  <p className="text-sm text-muted-foreground">{assignedTo.email}</p>
                </div>
              </div>
            </div>
          )}
          
          {/* Attachment if exists */}
          {ticket.attachmentUrl && (
            <div className="border border-gray-200 dark:border-gray-700 p-4 rounded-md">
              <h3 className="font-medium mb-2">Attachment</h3>
              <a 
                href={ticket.attachmentUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                View Attachment
              </a>
            </div>
          )}
          
          <div>
            <h3 className="font-medium mb-4 flex items-center">
              <MessageSquare className="h-5 w-5 mr-2" />
              Comments ({comments.length})
            </h3>
            
            <div className="space-y-4">
              {comments.length > 0 ? (
                comments.map((comment) => {
                  const commentUser = getUserById(comment.createdBy);
                  return (
                    <div key={comment.id} className="flex gap-4">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src="" />
                        <AvatarFallback>{commentUser ? getInitials(commentUser.name) : '??'}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded-md">
                          <div className="flex justify-between mb-2">
                            <span className="font-medium">{commentUser ? commentUser.name : 'Unknown User'}</span>
                            <span className="text-sm text-muted-foreground">
                              {new Date(comment.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="whitespace-pre-wrap">{comment.content}</p>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No comments yet.
                </div>
              )}
            </div>
            
            <Separator className="my-6" />
            
            <div className="space-y-4">
              <h3 className="font-medium">Add a Comment</h3>
              <Textarea
                placeholder="Write your comment here..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                rows={4}
              />
              <Button 
                onClick={handleSubmitComment} 
                disabled={!newComment.trim() || submittingComment}
              >
                Post Comment
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}