import { User, Ticket, Comment, Category } from "@/types";
import { v4 as uuidv4 } from 'uuid';

// Helper functions for localStorage
const getItem = <T>(key: string, defaultValue: T): T => {
  const item = localStorage.getItem(key);
  return item ? JSON.parse(item) : defaultValue;
};

const setItem = <T>(key: string, value: T): void => {
  localStorage.setItem(key, JSON.stringify(value));
};

// User management
export const getUsers = (): User[] => getItem<User[]>('quickdesk_users', []);

export const getUserById = (id: string): User | undefined => {
  return getUsers().find(user => user.id === id);
};

export const getUserByEmail = (email: string): User | undefined => {
  return getUsers().find(user => user.email === email);
};

export const createUser = (user: Omit<User, 'id' | 'createdAt'>): User => {
  const newUser: User = {
    ...user,
    id: uuidv4(),
    createdAt: new Date().toISOString(),
  };
  const users = getUsers();
  users.push(newUser);
  setItem('quickdesk_users', users);
  return newUser;
};

export const getCurrentUser = (): User | null => {
  const currentUserId = localStorage.getItem('quickdesk_current_user');
  if (!currentUserId) return null;
  
  return getUserById(currentUserId) || null;
};

export const setCurrentUser = (userId: string | null): void => {
  if (userId) {
    localStorage.setItem('quickdesk_current_user', userId);
  } else {
    localStorage.removeItem('quickdesk_current_user');
  }
};

// Category management
export const getCategories = (): Category[] => getItem<Category[]>('quickdesk_categories', []);

export const getCategoryById = (id: string): Category | undefined => {
  return getCategories().find(category => category.id === id);
};

export const createCategory = (category: Omit<Category, 'id' | 'createdAt'>): Category => {
  const newCategory: Category = {
    ...category,
    id: uuidv4(),
    createdAt: new Date().toISOString(),
  };
  const categories = getCategories();
  categories.push(newCategory);
  setItem('quickdesk_categories', categories);
  return newCategory;
};

export const updateCategory = (id: string, updates: Partial<Category>): Category | null => {
  const categories = getCategories();
  const index = categories.findIndex(c => c.id === id);
  
  if (index === -1) return null;
  
  const updatedCategory = { ...categories[index], ...updates };
  categories[index] = updatedCategory;
  setItem('quickdesk_categories', categories);
  return updatedCategory;
};

export const deleteCategory = (id: string): boolean => {
  const categories = getCategories();
  const filteredCategories = categories.filter(c => c.id !== id);
  
  if (filteredCategories.length === categories.length) return false;
  
  setItem('quickdesk_categories', filteredCategories);
  return true;
};

// Ticket management
export const getTickets = (): Ticket[] => getItem<Ticket[]>('quickdesk_tickets', []);

export const getTicketById = (id: string): Ticket | undefined => {
  return getTickets().find(ticket => ticket.id === id);
};

export const createTicket = (ticket: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'assignedTo' | 'votes'>): Ticket => {
  const now = new Date().toISOString();
  const newTicket: Ticket = {
    ...ticket,
    id: uuidv4(),
    status: 'open',
    assignedTo: null,
    createdAt: now,
    updatedAt: now,
    votes: {
      upvotes: 0,
      downvotes: 0,
      userVotes: {}
    }
  };
  const tickets = getTickets();
  tickets.push(newTicket);
  setItem('quickdesk_tickets', tickets);
  return newTicket;
};

export const updateTicket = (id: string, updates: Partial<Ticket>): Ticket | null => {
  const tickets = getTickets();
  const index = tickets.findIndex(t => t.id === id);
  
  if (index === -1) return null;
  
  const updatedTicket = { 
    ...tickets[index], 
    ...updates, 
    updatedAt: new Date().toISOString() 
  };
  tickets[index] = updatedTicket;
  setItem('quickdesk_tickets', tickets);
  return updatedTicket;
};

export const voteTicket = (ticketId: string, userId: string, voteType: 'up' | 'down' | null): Ticket | null => {
  const tickets = getTickets();
  const index = tickets.findIndex(t => t.id === ticketId);
  
  if (index === -1) return null;
  
  const ticket = tickets[index];
  const currentVote = ticket.votes.userVotes[userId];
  
  // Remove previous vote if exists
  if (currentVote === 'up') ticket.votes.upvotes--;
  if (currentVote === 'down') ticket.votes.downvotes--;
  
  // Add new vote if not null
  if (voteType === 'up') ticket.votes.upvotes++;
  if (voteType === 'down') ticket.votes.downvotes++;
  
  // Update user vote record
  ticket.votes.userVotes[userId] = voteType;
  
  setItem('quickdesk_tickets', tickets);
  return ticket;
};

// Comment management
export const getComments = (): Comment[] => getItem<Comment[]>('quickdesk_comments', []);

export const getCommentsByTicketId = (ticketId: string): Comment[] => {
  return getComments().filter(comment => comment.ticketId === ticketId);
};

export const createComment = (comment: Omit<Comment, 'id' | 'createdAt'>): Comment => {
  const newComment: Comment = {
    ...comment,
    id: uuidv4(),
    createdAt: new Date().toISOString(),
  };
  const comments = getComments();
  comments.push(newComment);
  setItem('quickdesk_comments', comments);
  return newComment;
};

// Initialize some default data if it doesn't exist
export const initializeDefaultData = () => {
  // Check if we already have users
  const users = getUsers();
  if (users.length === 0) {
    createUser({ email: 'admin@quickdesk.com', name: 'Admin User', role: 'admin' });
    createUser({ email: 'agent@quickdesk.com', name: 'Support Agent', role: 'agent' });
    createUser({ email: 'user@quickdesk.com', name: 'Regular User', role: 'user' });
  }
  
  // Check if we already have categories
  const categories = getCategories();
  if (categories.length === 0) {
    createCategory({ name: 'Technical Issue', description: 'For technical problems with the system' });
    createCategory({ name: 'Billing', description: 'For questions about billing and payments' });
    createCategory({ name: 'Feature Request', description: 'For suggesting new features' });
    createCategory({ name: 'General Inquiry', description: 'For general questions' });
  }
};