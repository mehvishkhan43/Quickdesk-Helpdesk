import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { LifeBuoy } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AuthLayout() {
  const { user, isLoading } = useAuth();
  
  // If user is logged in, redirect to dashboard
  if (user && !isLoading) {
    return <Navigate to="/dashboard" replace />;
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <div className="container max-w-md mx-auto flex-1 flex flex-col items-center justify-center px-4">
        <div className="bg-white dark:bg-gray-800 px-6 py-8 rounded-lg shadow-md w-full">
          <div className="flex justify-center mb-6">
            <Link to="/" className="flex items-center">
              <LifeBuoy className="h-8 w-8 mr-2 text-blue-600 dark:text-blue-400" />
              <span className="text-2xl font-bold">QuickDesk</span>
            </Link>
          </div>
          
          <Outlet />
        </div>
      </div>
    </div>
  );
}